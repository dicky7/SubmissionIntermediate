package com.example.mystoryapp.ui.home.homeStory

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.mystoryapp.data.MyStoryRepository
import com.example.mystoryapp.data.Result
import com.example.mystoryapp.data.remote.response.ListStoryItem
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch


class HomeViewModel(private val myStoryRepository: MyStoryRepository):ViewModel() {
    fun getAuthToken(): Flow<String> = myStoryRepository.getAuthToken()

    fun getStories(token: String): LiveData<Result<List<ListStoryItem>>> = myStoryRepository.getStories(token,null, null)

    /**
     * set state login
     */
    fun setIsLoggedIn(isBoolean: Boolean) {
        viewModelScope.launch {
            myStoryRepository.setLoggedIn(isBoolean)
        }
    }
}